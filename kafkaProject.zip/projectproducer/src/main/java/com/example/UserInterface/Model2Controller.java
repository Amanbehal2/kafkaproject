package com.example.UserInterface;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.bean1.Model2;

import com.example.service.Model2Service;


@RestController
@RequestMapping("kafka")
public class Model2Controller {
  
	@Autowired
  private Model2Service model2;

  private int id;
  private String fullName;
  private long pan;
  private String address;
  
  @Autowired
  KafkaTemplate<String,Model2> Kafkatemplate;
  private static final String Topic="model2";
  @GetMapping("/publish1/{id}")
  public String post(@PathVariable("id") final int id ) {
	
	   Kafkatemplate.send(Topic,new Model2(id,fullName,pan, address));
	   return "published";
  }
  
 
  @PostMapping("/createModel2")
  public int createModel2(@RequestBody Model2 model12) {
	System.out.println(model12);
	  return model2.addmodel2User(model12);
	 
	 
	
  }
}
