package com.example.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.example.bean1.Model1;
import com.example.bean1.Model2;


@Configuration
public class kafkaProducerConfiguration {
@Bean 
public ProducerFactory<String,Model1> producerfactory() {
	Map<String , Object> config=new HashMap<>();
    config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
    config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    return new DefaultKafkaProducerFactory<>(config);
}
@Bean 
public KafkaTemplate<String, Model1> kafkatemplate(){
	return  new KafkaTemplate<>(producerfactory());
}
@Bean
public ProducerFactory<String,Model2> producerfactory1() {
	Map<String , Object> config=new HashMap<>();
    config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
    config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    return new DefaultKafkaProducerFactory<>(config);
}
@Bean 
public KafkaTemplate<String, Model2> kafkatemplate1(){
	return  new KafkaTemplate<>(producerfactory1());
}
   
}