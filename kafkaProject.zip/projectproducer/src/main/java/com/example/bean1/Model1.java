package com.example.bean1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Model1")

public class Model1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="First_Name")
	private String first_Name;
	@Column(name="Last_Name")
	private String last_Name;
	@Column(name="Address_1")
	private String address_1;
	@Column(name="address_2")
	private String Address_2;
	@Column(name="Shopping_Interest")
	private String shopping_Interests;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return last_Name;
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}
	public String getAddress_1() {
		return address_1;
	}
	public void setAddress_1(String address_1) {
		this.address_1 = address_1;
	}
	public String getAddress_2() {
		return Address_2;
	}
	public void setAddress_2(String address_2) {
		Address_2 = address_2;
	}
	public String getShopping_Interests() {
		return shopping_Interests;
	}
	public void setShopping_Interests(String shopping_Interests) {
		this.shopping_Interests = shopping_Interests;
	}
	public Model1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Model1(int id, String first_Name, String last_Name, String address_1, String address_2,
			String shopping_Interests) {
		super();
		this.id = id;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.address_1 = address_1;
		Address_2 = address_2;
		this.shopping_Interests = shopping_Interests;
	}
	@Override
	public String toString() {
		return "Model1 [first_Name=" + first_Name + ", last_Name=" + last_Name + ", address_1=" + address_1
				+ ", Address_2=" + Address_2 + ", shopping_Interests=" + shopping_Interests + "]";
	}
	
	
	
}
