package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Repo.Model2Repo;
import com.example.bean1.Model2;

@Service
@Transactional
public class model2ServiceImpl implements Model2Service{
   
	@Autowired
	Model2Repo model2_1;

	@Override
	public int addmodel2User(Model2 model2) {
		model2_1.save(model2);
		return model2.getId();
		
	}

	@Override
	public List<Model2> showModel2() {
		
		return model2_1.findAll();
	}

	
}
