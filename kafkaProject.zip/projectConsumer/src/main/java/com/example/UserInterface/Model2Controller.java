/*
 * package com.example.UserInterface;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.kafka.annotation.KafkaListener; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.example.bean1.Model1; import com.example.bean1.Model2; import
 * com.example.service.Model2Service;
 * 
 * @RestController
 * 
 * @RequestMapping("kafka") public class Model2Controller {
 * 
 * @Autowired private Model2Service model2;
 * 
 * @KafkaListener(topics="kafkaModel2",groupId
 * ="group_json1",containerFactory="kafkaListenerContainerFactory") public void
 * consumeJson(Model2 model22 ) {
 * System.out.println("consumer message"+model22);
 * model2.addmodel2User(model22); } }
 */