package com.example.bean1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Model2")

public class Model2 {
	  @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
		private int id; 
	@Column(name="FullName")
	private String fullName;
	@Column(name="PAN")

	private long pan;
	@Column(name="Address")
	private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public long getPan() {
		return pan;
	}
	public void setPan(long pan) {
		this.pan = pan;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Model2(int id, String fullName, long pan, String address) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.pan = pan;
		this.address = address;
	}
	public Model2() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Model2 [fullName=" + fullName + ", pan=" + pan + ", address=" + address + "]";
	}
}
